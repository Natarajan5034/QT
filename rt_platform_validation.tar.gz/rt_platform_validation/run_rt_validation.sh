#!/bin/bash
# Basic automatic wrapper for rt_platform_test
set -u

APP="$(dirname "$0")/rt_platform_test"

if [ ! -x "$APP" ]; then
    echo "[FAIL] $APP not found or not executable"
    echo "Build first:"
    echo "  gcc -O2 -Wall -Wextra -pthread rt_platform_test.c -o rt_platform_test"
    exit 1
fi

echo "=============================================="
echo " RT PLATFORM VALIDATION"
echo "=============================================="
echo
echo "Kernel:"
uname -a
echo
echo "CPU:"
lscpu | grep -E '^(CPU\(s\)|On-line CPU|Thread|Core|Socket)'
echo
echo "PREEMPT_RT config:"
grep -E 'CONFIG_PREEMPT(_RT)?=' "/boot/config-$(uname -r)" 2>/dev/null || true
echo
echo "Runtime RT interface:"
if [ -e /sys/kernel/realtime ]; then
    cat /sys/kernel/realtime
else
    echo "not available"
fi
echo
echo "Scheduler:"
chrt -p $$
echo
echo "Run sample:"
echo

# Default: 1 ms period, 100000 cycles, priority 80.
# Add -l manually if CPU-load testing is desired.
"$APP" -p 80 -i 1000 -n 100000

echo
echo "=============================================="
echo " OPTIONAL STRESS RUN"
echo "=============================================="
echo "Run the following separately if stress-ng is installed:"
echo
echo "  sudo stress-ng --cpu 2 --io 2 --vm 1 --timeout 60s"
echo "  sudo $APP -p 80 -i 1000 -n 100000 -c 1"
echo
echo "Do not define a universal PASS latency number."
echo "Compare measured latency against your product requirement."
