# RT Platform Validation Sample

## What this validates

This sample checks generic RT-platform mechanisms:

1. Running kernel information
2. `/sys/kernel/realtime` when provided by the kernel
3. Number of CPUs visible to the process
4. `SCHED_FIFO`
5. `SCHED_RR`
6. CPU affinity
7. `mlockall()`
8. Priority-inheritance mutex
9. Periodic timer wake-up error/jitter
10. Optional CPU load

## Build on RHEL 9.2

```bash
gcc -O2 -Wall -Wextra -pthread rt_platform_test.c -o rt_platform_test
```

If GCC is missing, install the appropriate development toolchain for your RHEL environment.

## Basic run

```bash
sudo ./rt_platform_test
```

## CPU affinity

For CPU 1:

```bash
sudo ./rt_platform_test -c 1
```

## Longer 1-ms timer test

```bash
sudo ./rt_platform_test -p 80 -i 1000 -n 1000000 -c 1
```

## CPU-load run

```bash
sudo ./rt_platform_test -p 80 -i 1000 -n 100000 -c 1 -l
```

## Important interpretation

A successful SCHED_FIFO call proves that the application can request RT scheduling; it does not prove that the platform meets a particular latency requirement.

The timer section reports:

- minimum wake-up error
- maximum wake-up error
- average absolute error
- deadline misses (> one requested period late)

Your project should define an actual requirement, for example:

```text
Period: 1 ms
Maximum allowed latency: X us
Maximum allowed jitter: Y us
Maximum deadline misses: 0
```

Do not copy X/Y from this example; they must come from your system requirement.

## What this does NOT validate

A generic application cannot validate a specific PCIe/DMA/FPGA device because the driver API is device-specific.

For your PCIe/DMA platform, add a second stage:

```text
PCIe detected
  -> driver loaded
  -> /dev node exists
  -> expected major number
  -> BAR/MMIO access
  -> DMA allocation
  -> DMA transfer
  -> DMA completion interrupt
  -> data integrity
  -> repeated transfers
```

Use your existing DMA application for this hardware-specific stage.

## Recommended baseline

Run the same suite on:

1. normal kernel
2. RT kernel

Save:

```text
kernel version
CPU configuration
SCHED_FIFO result
SCHED_RR result
timer period
minimum error
maximum error
average error
deadline misses
PCIe/DMA results
```

Then repeat after changing the kernel, driver, BIOS, CPU isolation, or hardware configuration.
