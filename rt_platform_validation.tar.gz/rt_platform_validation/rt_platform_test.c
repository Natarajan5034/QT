/*
 * rt_platform_test.c
 *
 * Generic RHEL PREEMPT_RT platform validation sample.
 *
 * Tests:
 *  1. Running kernel identification / RT sysfs interface
 *  2. SCHED_FIFO
 *  3. SCHED_RR
 *  4. CPU affinity
 *  5. mlockall()
 *  6. Priority-inheritance mutex
 *  7. Periodic timer latency/jitter using clock_nanosleep()
 *  8. Optional CPU load thread
 *
 * NOTE:
 * This does NOT validate a specific PCIe/DMA/FPGA driver. Those require
 * device-specific IOCTLs/API. Add your DMA test after this platform test.
 *
 * Build:
 *   gcc -O2 -Wall -Wextra -pthread rt_platform_test.c -o rt_platform_test
 *
 * Run:
 *   sudo ./rt_platform_test
 *
 * Optional:
 *   sudo ./rt_platform_test -p 80 -i 1000 -n 100000 -c 1
 *
 *   -p RT priority (1..99)
 *   -i timer period in microseconds
 *   -n number of timer cycles
 *   -c CPU number for affinity (-1 = no affinity)
 *   -l enable a CPU-load thread
 */

#define _GNU_SOURCE
#include <errno.h>
#include <inttypes.h>
#include <pthread.h>
#include <sched.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <sys/resource.h>
#include <sys/sysinfo.h>
#include <sys/utsname.h>
#include <time.h>
#include <unistd.h>

static int g_priority = 80;
static long g_period_us = 1000;
static long g_cycles = 100000;
static int g_cpu = -1;
static int g_load = 0;

static volatile sig_atomic_t g_stop = 0;

static void on_sigint(int sig)
{
    (void)sig;
    g_stop = 1;
}

static int64_t timespec_to_ns(const struct timespec *t)
{
    return (int64_t)t->tv_sec * 1000000000LL + t->tv_nsec;
}

static struct timespec ns_to_timespec(int64_t ns)
{
    struct timespec t;
    t.tv_sec = ns / 1000000000LL;
    t.tv_nsec = ns % 1000000000LL;
    return t;
}

static void print_result(const char *name, int pass)
{
    printf("[%s] %s\n", pass ? "PASS" : "FAIL", name);
}

static void kernel_test(void)
{
    struct utsname u;
    FILE *f;
    char buf[128] = {0};
    int realtime = -1;

    printf("\n=== 1. KERNEL ===\n");

    if (uname(&u) == 0) {
        printf("Kernel release : %s\n", u.release);
        printf("Kernel version : %s\n", u.version);
    }

    f = fopen("/sys/kernel/realtime", "r");
    if (f) {
        if (fgets(buf, sizeof(buf), f))
            realtime = atoi(buf);
        fclose(f);
    }

    if (realtime == 1) {
        print_result("PREEMPT_RT runtime interface", 1);
    } else if (realtime == 0) {
        printf("[INFO] /sys/kernel/realtime = 0\n");
        print_result("PREEMPT_RT runtime interface", 0);
    } else {
        printf("[WARN] /sys/kernel/realtime is not available on this kernel.\n");
        printf("       Check /boot/config-$(uname -r) for CONFIG_PREEMPT_RT.\n");
    }
}

static void cpu_test(void)
{
    int n = get_nprocs();
    printf("\n=== 2. CPU ===\n");
    printf("Online/configured CPUs visible to process: %d\n", n);
    print_result("At least one CPU available", n > 0);

    if (g_cpu >= 0) {
        cpu_set_t set;
        CPU_ZERO(&set);
        CPU_SET(g_cpu, &set);

        int rc = sched_setaffinity(0, sizeof(set), &set);
        if (rc == 0) {
            cpu_set_t actual;
            CPU_ZERO(&actual);
            if (sched_getaffinity(0, sizeof(actual), &actual) == 0 &&
                CPU_ISSET(g_cpu, &actual)) {
                printf("Process affinity set to CPU %d\n", g_cpu);
                print_result("CPU affinity", 1);
            } else {
                print_result("CPU affinity", 0);
            }
        } else {
            printf("sched_setaffinity: %s\n", strerror(errno));
            print_result("CPU affinity", 0);
        }
    } else {
        printf("[INFO] CPU affinity test skipped (-c not specified).\n");
    }
}

static void scheduler_test_one(int policy, const char *name)
{
    struct sched_param oldp, p;
    int old_policy = sched_getscheduler(0);

    if (old_policy < 0) {
        printf("%s: sched_getscheduler failed: %s\n", name, strerror(errno));
        print_result(name, 0);
        return;
    }

    if (sched_getparam(0, &oldp) != 0) {
        printf("sched_getparam failed: %s\n", strerror(errno));
        print_result(name, 0);
        return;
    }

    p.sched_priority = g_priority;

    if (sched_setscheduler(0, policy, &p) != 0) {
        printf("%s: %s\n", name, strerror(errno));
        print_result(name, 0);
        return;
    }

    int now = sched_getscheduler(0);
    struct sched_param verify;
    int ok = (now == policy &&
              sched_getparam(0, &verify) == 0 &&
              verify.sched_priority == g_priority);

    printf("%s priority: %d\n", name, verify.sched_priority);
    print_result(name, ok);

    /* Restore normal scheduling so the next test starts cleanly. */
    struct sched_param normal = { .sched_priority = 0 };
    (void)sched_setscheduler(0, SCHED_OTHER, &normal);

    (void)old_policy;
    (void)oldp;
}

static void scheduler_test(void)
{
    printf("\n=== 3. REAL-TIME SCHEDULER ===\n");
    scheduler_test_one(SCHED_FIFO, "SCHED_FIFO");
    scheduler_test_one(SCHED_RR, "SCHED_RR");
}

static void memory_test(void)
{
    printf("\n=== 4. MEMORY LOCKING ===\n");

    if (mlockall(MCL_CURRENT | MCL_FUTURE) == 0) {
        print_result("mlockall(MCL_CURRENT|MCL_FUTURE)", 1);
    } else {
        printf("mlockall failed: %s\n", strerror(errno));
        printf("You may need root/appropriate memlock limits.\n");
        print_result("mlockall(MCL_CURRENT|MCL_FUTURE)", 0);
    }

    /* Touch a small amount of memory after mlockall(). */
    size_t sz = 1024 * 1024;
    volatile unsigned char *p = malloc(sz);
    if (p) {
        for (size_t i = 0; i < sz; i += 4096)
            p[i] = (unsigned char)i;
        free((void *)p);
        print_result("Memory allocation/touch after mlockall", 1);
    } else {
        print_result("Memory allocation/touch after mlockall", 0);
    }
}

static void mutex_pi_test(void)
{
    printf("\n=== 5. PRIORITY INHERITANCE MUTEX ===\n");

    pthread_mutexattr_t attr;
    pthread_mutex_t mutex;

    if (pthread_mutexattr_init(&attr) != 0) {
        print_result("pthread_mutexattr_init", 0);
        return;
    }

    int rc = pthread_mutexattr_setprotocol(&attr, PTHREAD_PRIO_INHERIT);
    if (rc != 0) {
        printf("pthread_mutexattr_setprotocol: %s\n", strerror(rc));
        print_result("PTHREAD_PRIO_INHERIT", 0);
        pthread_mutexattr_destroy(&attr);
        return;
    }

    rc = pthread_mutex_init(&mutex, &attr);
    pthread_mutexattr_destroy(&attr);

    if (rc != 0) {
        printf("pthread_mutex_init: %s\n", strerror(rc));
        print_result("PI mutex creation", 0);
        return;
    }

    rc = pthread_mutex_lock(&mutex);
    if (rc == 0) {
        pthread_mutex_unlock(&mutex);
        print_result("PTHREAD_PRIO_INHERIT mutex", 1);
    } else {
        printf("pthread_mutex_lock: %s\n", strerror(rc));
        print_result("PTHREAD_PRIO_INHERIT mutex", 0);
    }

    pthread_mutex_destroy(&mutex);
}

static void *load_thread(void *arg)
{
    (void)arg;
    volatile unsigned long x = 0;

    while (!g_stop) {
        for (unsigned long i = 0; i < 500000; ++i)
            x = x * 1664525UL + 1013904223UL;
    }

    return NULL;
}

static void timer_test(void)
{
    printf("\n=== 6. PERIODIC TIMER / JITTER ===\n");
    printf("Period: %ld us, cycles: %ld\n", g_period_us, g_cycles);

    struct sched_param p = { .sched_priority = g_priority };
    if (sched_setscheduler(0, SCHED_FIFO, &p) != 0) {
        printf("Could not set SCHED_FIFO: %s\n", strerror(errno));
        printf("Timer test will run with current scheduler.\n");
    }

    if (g_cpu >= 0) {
        cpu_set_t set;
        CPU_ZERO(&set);
        CPU_SET(g_cpu, &set);
        if (sched_setaffinity(0, sizeof(set), &set) != 0)
            printf("Warning: affinity failed: %s\n", strerror(errno));
    }

    struct timespec start;
    if (clock_gettime(CLOCK_MONOTONIC, &start) != 0) {
        perror("clock_gettime");
        return;
    }

    int64_t start_ns = timespec_to_ns(&start);
    int64_t period_ns = g_period_us * 1000LL;

    int64_t min_err = INT64_MAX;
    int64_t max_err = INT64_MIN;
    int64_t sum_abs = 0;
    int64_t misses = 0;

    for (long i = 1; i <= g_cycles && !g_stop; ++i) {
        int64_t target_ns = start_ns + (int64_t)i * period_ns;
        struct timespec target = ns_to_timespec(target_ns);

        int rc;
        do {
            rc = clock_nanosleep(CLOCK_MONOTONIC, TIMER_ABSTIME,
                                 &target, NULL);
        } while (rc == EINTR && !g_stop);

        if (rc != 0 && rc != EINTR) {
            printf("clock_nanosleep: %s\n", strerror(rc));
            break;
        }

        struct timespec now;
        clock_gettime(CLOCK_MONOTONIC, &now);
        int64_t actual_ns = timespec_to_ns(&now);
        int64_t err = actual_ns - target_ns;

        if (err < min_err) min_err = err;
        if (err > max_err) max_err = err;
        sum_abs += llabs(err);

        /*
         * "Miss" here means the wakeup is more than one requested period late.
         * This is a sample criterion, not a universal application deadline.
         */
        if (err > period_ns)
            misses++;
    }

    long completed = g_cycles;
    if (g_stop)
        completed = 0; /* Exact count is not critical for this sample. */

    printf("Minimum wakeup error : %" PRId64 " ns\n", min_err);
    printf("Maximum wakeup error : %" PRId64 " ns\n", max_err);
    if (min_err != INT64_MAX)
        printf("Maximum absolute jitter: %" PRId64 " ns\n",
               llabs(min_err) > llabs(max_err) ? llabs(min_err) : llabs(max_err));
    if (g_cycles > 0)
        printf("Average absolute error: %" PRId64 " ns\n",
               sum_abs / g_cycles);
    printf("Deadline misses (>1 period late): %" PRId64 "\n", misses);
    printf("Cycles requested: %ld\n", completed);

    /*
     * Do not hard-code a "RT PASS" latency number here. The acceptable
     * latency depends on the product requirement. Treat these as measurements.
     */
    print_result("Periodic timer executed", min_err != INT64_MAX);

    struct sched_param normal = { .sched_priority = 0 };
    (void)sched_setscheduler(0, SCHED_OTHER, &normal);
}

static void print_usage(const char *prog)
{
    printf("Usage: %s [-p priority] [-i period_us] [-n cycles] [-c cpu] [-l]\n", prog);
    printf("  -p priority   SCHED_FIFO/RR priority, 1..99 (default 80)\n");
    printf("  -i period_us  timer period in microseconds (default 1000)\n");
    printf("  -n cycles      number of timer cycles (default 100000)\n");
    printf("  -c cpu         CPU for affinity, -1 means no affinity (default -1)\n");
    printf("  -l             run CPU-load thread during timer test\n");
}

int main(int argc, char **argv)
{
    int opt;

    signal(SIGINT, on_sigint);
    signal(SIGTERM, on_sigint);

    while ((opt = getopt(argc, argv, "p:i:n:c:lh")) != -1) {
        switch (opt) {
        case 'p':
            g_priority = atoi(optarg);
            break;
        case 'i':
            g_period_us = atol(optarg);
            break;
        case 'n':
            g_cycles = atol(optarg);
            break;
        case 'c':
            g_cpu = atoi(optarg);
            break;
        case 'l':
            g_load = 1;
            break;
        case 'h':
        default:
            print_usage(argv[0]);
            return 0;
        }
    }

    if (g_priority < 1 || g_priority > 99 ||
        g_period_us <= 0 || g_cycles <= 0) {
        print_usage(argv[0]);
        return 1;
    }

    printf("=============================================\n");
    printf("       RT PLATFORM VALIDATION SAMPLE\n");
    printf("=============================================\n");

    kernel_test();
    cpu_test();
    scheduler_test();
    memory_test();
    mutex_pi_test();

    pthread_t load_tid;
    int load_started = 0;

    if (g_load) {
        if (pthread_create(&load_tid, NULL, load_thread, NULL) == 0) {
            load_started = 1;
            printf("\n[INFO] CPU load thread started.\n");
        } else {
            printf("[WARN] Could not start CPU load thread.\n");
        }
    }

    timer_test();

    g_stop = 1;
    if (load_started)
        pthread_join(load_tid, NULL);

    printf("\n=============================================\n");
    printf("Validation completed.\n");
    printf("IMPORTANT: latency values must be compared with your product's\n");
    printf("real-time deadline/jitter requirement.\n");
    printf("=============================================\n");

    return 0;
}
